<template>
    <div class="main">

    </div>
</template>

<style  scoped>
.main {
    text-align: center;
    padding: 5px;
    background: white;
    height: 100%;
    background-image: url("../assets/img/index.gif");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position-y: bottom;
}
</style>