// 全局变量
export default {
  name: '知否君',
  officialAccount: '知否技术'
}
